#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <iostream>

using namespace std;
using namespace sf;


size_t len(char s[])
{
    size_t reval = 0;
    for(size_t i = 0; s[i] != 0; i++)
    {
        reval++;
    }
    return reval;
}
void playOneSound(char n)
{
    string gf = "sounds/";
    switch(n)
    {
        case '0': gf += "zero.ogg"; break;
        case '1': gf += "one.ogg"; break;
        case '2': gf += "two.ogg"; break;
        case '3': gf += "three.ogg"; break;
        case '4': gf += "four.ogg"; break;
        case '5': gf += "five.ogg"; break;
        case '6': gf += "six.ogg"; break;
        case '7': gf += "seven.ogg"; break;
        case '8': gf += "eight.ogg"; break;
        case '9': gf += "nine.ogg";
    }
    SoundBuffer buf;
    Sound sound;
    buf.loadFromFile(gf);
    sound.setBuffer(buf);
    sound.play();
    while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
}

void playTowSound(char ss[])
{
    string gf = "sounds/";
    SoundBuffer buf;
    Sound sound;
    if(ss[0] != '1')
    {
        if(ss[1] != '0')
        {
            playOneSound(ss[1]);
            buf.loadFromFile("sounds/and.ogg");
            sound.setBuffer(buf);
            sound.play();
            while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
        }
        switch(ss[0])
        {
            case '2': gf += "twenty.ogg"; break;
            case '3': gf += "thirty.ogg"; break;
            case '4': gf += "forty.ogg"; break;
            case '5': gf += "fifty.ogg"; break;
            case '6': gf += "sixty.ogg"; break;
            case '7': gf += "seventy.ogg"; break;
            case '8': gf += "eighty.ogg"; break;
            case '9': gf += "ninety.ogg";
        }
        buf.loadFromFile(gf);
        sound.setBuffer(buf);
        sound.play();
        while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
    }
    else
    {
        gf += "special_case/";
        switch(ss[1])
        {
            case '0': gf += "ten.ogg"; break;
            case '1': gf += "eleven.ogg"; break;
            case '2': gf += "twelve.ogg"; break;
            case '3': gf += "thirteen.ogg"; break;
            case '4': gf += "fourteen.ogg"; break;
            case '5': gf += "fifteen.ogg"; break;
            case '6': gf += "sixteen.ogg"; break;
            case '7': gf += "seventeen.ogg"; break;
            case '8': gf += "eighteen.ogg"; break;
            case '9': gf += "nineteen.ogg";
        }
        buf.loadFromFile(gf);
        sound.setBuffer(buf);
        sound.play();
        while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
    }
}
void playThreeSound(char ss[])
{
    string gf = "sounds/";
    SoundBuffer buf;
    Sound sound;
    switch(ss[0])
    {
        case '1': gf += "hundred.ogg"; break;
        case '2': gf += "twohundred.ogg"; break;
        case '3': gf += "threehundred.ogg"; break;
        case '4': gf += "fourhundred.ogg"; break;
        case '5': gf += "fivehundred.ogg"; break;
        case '6': gf += "sixhundred.ogg"; break;
        case '7': gf += "sevenhundred.ogg"; break;
        case '8': gf += "eighthundred.ogg"; break;
        case '9': gf += "ninehundred.ogg";
    }
    buf.loadFromFile(gf);
    sound.setBuffer(buf);
    sound.play();
    while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
    if(ss[1] != '0' || ss[2] != '0')
    {
        if(ss[1] == '0')
        {
            gf = "sounds/and.ogg";
            buf.loadFromFile(gf);
            sound.setBuffer(buf);
            sound.play();
            while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
            playOneSound(ss[2]);
        }
        else
        {
            if(ss[1] == '1')
            {
                gf = "sounds/and.ogg";
                buf.loadFromFile(gf);
                sound.setBuffer(buf);
                sound.play();
                while(sound.getStatus() == Sound::Playing){sleep(milliseconds(1.f));}
            }
            char sg[3];
            sg[2] = 0;
            sg[0] = ss[1];
            sg[1] = ss[2];
            playTowSound(sg);
        }
    }
}

int main()
{
    char in[4];
    cout << "Type a number (3 digits or less only):\n";
    cin >> in;
    size_t size = len(in);
    if(size == 1)
    {
        playOneSound(in[0]);
    }
    else if(size == 2)
    {
        playTowSound(in);
    }
    else if(size == 3)
    {
        playThreeSound(in);
    }
    return 0;
}
